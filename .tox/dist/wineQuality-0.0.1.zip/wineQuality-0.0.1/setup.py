from setuptools import setup, find_packages

setup(
    name="wineQuality", version="0.0.1",
    description="It is a wine quality package with MLOps",
    author="Atul Rai",
    packages=find_packages(),
    license="MIT"
)