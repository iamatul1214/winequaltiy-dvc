def test_generic():
    a=2
    b=3
    assert a != b